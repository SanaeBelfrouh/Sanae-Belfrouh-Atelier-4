package com.example.sanae_belfrouh_atelier4;

import android.os.Bundle;
import android.widget.GridView;
import androidx.appcompat.app.AppCompatActivity;
import java.io.File;
import java.util.ArrayList;

public class GalleryActivity extends AppCompatActivity {

    private GridView gridView;
    private ArrayList<String> imagePaths;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gallery);

        gridView = findViewById(R.id.grid_view);

        // Get all image file paths
        imagePaths = new ArrayList<>();
        File directory = getFilesDir();
        File[] files = directory.listFiles();
        for (File file : files) {
            if (file.getName().endsWith(".jpg")) {
                imagePaths.add(file.getAbsolutePath());
            }
        }

        // Set up grid view adapter
        ImageAdapter adapter = new ImageAdapter(this, imagePaths);
        gridView.setAdapter(adapter);
    }
}
